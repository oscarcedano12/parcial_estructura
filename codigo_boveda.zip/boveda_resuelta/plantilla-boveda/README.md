# Bóveda de fichas — Laboratorio de estructuras de datos

Programa Java que lee fichas de un `.txt`, valida formato y anidamiento y, si todo es válido,
procesa las pistas por prioridad para formar el mensaje final (el ejemplo produce **SOL**).
Hay dos versiones de la misma lógica: **manual** (lista, pila y colas propias) y **java.util**,
y el programa verifica que ambas produzcan el mismo mensaje, el mismo primer error y la misma traza.

## Compilar y ejecutar

```bash
javac -encoding UTF-8 -d out $(find src -name "*.java")

java -cp out app.Main datos/ejemplo_valido.txt      # SOL
java -cp out app.Main datos/ejemplo_invalido.txt    # error en línea 6, ficha F05
java -cp out pruebas.CasosPrueba datos              # 94 pruebas, código de salida 0 si todas pasan
```

Códigos de salida de `Main`: `0` válido y versiones equivalentes · `1` error en el archivo ·
`2` uso incorrecto / archivo ilegible · `3` las versiones difieren (defecto del programa).

## Mapa del código

| Paquete | Clase | Responsabilidad |
|---|---|---|
| `dominio` | `Ficha`, `TipoFicha` | Registro inmutable de una fila (con línea física y posición). |
| `dominio` | `Pista` | Tarea que viaja por las colas; las generadas por ENCADENAR heredan prioridad y origen. |
| `dominio` | `ErrorBoveda`, `Informe`, `Eventos` | Error con fase/línea/ficha, resultado comparable y formato único de la traza. |
| `app` | `LectorFichas` | **Fase 1.** Lee UTF-8 y valida encabezado, 5 campos, tipo, valor, prioridad, sintaxis de instrucción, ids únicos. |
| `manual` | `ListaFichas`, `PilaSimbolos`, `ColaPistas` | Estructuras propias sobre `Nodo<T>`. |
| `manual` | `ValidadorManual` | **Fases 2–5** con las estructuras propias. |
| `biblioteca` | `ValidadorBiblioteca` | **Fases 2–5** con `LinkedList`/`HashMap`, `ArrayDeque`, `Queue` y `HashSet`. |
| `app` | `Main` | Ejecuta ambas versiones, imprime las trazas y compara. |
| `pruebas` | `CasosPrueba` | Estructuras aisladas, archivos de `datos/`, trazas y casos de frontera. |

## Reglas y decisiones (puntos que el enunciado deja abiertos)

* **Orden de errores:** primero por fase (1 lectura → 3 pila → 5 resolución) y dentro de cada fase por orden de lectura o de atención. Un error corta las fases siguientes y conserva la traza producida.
* **Fase 1 solo revisa sintaxis** de `REVELAR:id` / `ENCADENAR:id1:id2`. Que el id exista, sea LETRA o ya esté revelada se descubre **al atender la pista** (fase 5), con la búsqueda registrada en la traza. Por eso un error de pila (fase 3) tiene prioridad sobre una referencia inexistente.
* **Apertura sobrante:** se reporta la apertura **más reciente** sin cerrar (el tope), con su línea y ficha.
* **ENCADENAR:id1:id2:** revela `id1` (busca, valida, revela), valida que `id2` exista y sea LETRA, y recién entonces encola `REVELAR:id2` al final de la **misma prioridad**. Que `id2` ya esté revelada se detecta cuando la pista generada se atiende.
* **Errores de una pista generada** se reportan con la línea y ficha de la ficha PISTA que la originó (`gen(F09)`).
* **Archivo:** se ignoran líneas vacías al final y un BOM UTF-8 inicial; una línea vacía en medio es "línea incompleta". Los campos no se recortan (un espacio sobrante es un error de formato).

## Pseudocódigo

```
Fase 1  leer(ruta):
    lineas ← leerUTF8(ruta);  validar encabezado exacto
    para i = 2..n:  c ← split(línea, '|');  exigir 5 campos
        validar id (único), tipo, valor según tipo, prioridad ∈ {1,2,3}, instrucción
        fichas.add(Ficha(..., posicion = fichas.size+1, linea = i))      # primer error → ErrorBoveda

Fase 2  para f en fichas: lista.agregar(f)                               # O(1) c/u
        recorrido ← ids de la lista en orden

Fase 3  para f en lista (en orden):
            ABRE   → pila.apilar(f.valor)
            CIERRA → si pila vacía → ERROR "cierre sin apertura"
                     tope ← pila.consultar()
                     si cierreDe(tope) ≠ f.valor → ERROR "se esperaba X porque tope está en el tope"
                     pila.retirar()
        si pila no vacía → ERROR "apertura sobrante"

Fase 4  para f en lista, f.tipo = PISTA:  colas.encolar(Pista(f), f.prioridad)

Fase 5  mientras colas no vacías:
            p ← colas.desencolar()                    # P1, luego P2, luego P3; FIFO dentro
            revelar(p.id1):  l ← lista.buscar(id)
                             inexistente / no LETRA / ya revelada → ERROR
                             marcar revelada; mensaje += l.valor
            si p es ENCADENAR: validar id2 (existe y es LETRA)
                               colas.encolar(REVELAR:id2, p.prioridad)   # al final de su cola
```

## Invariantes

* **Lista:** `tamanio` = nodos alcanzables desde `cabeza`; `cabeza == null ⇔ cola == null ⇔ tamanio == 0`; `cola.siguiente == null`; el orden es el de inserción.
* **Pila:** `tope == null ⇔ tamanio == 0`; solo `apilar` y `retirar` la modifican (`consultar` no).
* **Colas:** para cada prioridad `frente == null ⇔ fin == null ⇔ tamanio == 0`; al vaciarse una cola se reinician **ambos** punteros (si no, un `ENCADENAR` sobre una cola vacía perdería la pista generada). Dentro de una prioridad, orden de llegada.
* **Mensaje:** cada letra se agrega a lo sumo una vez (arreglo `reveladas[posición]` en la versión manual, `HashSet` en la de biblioteca).
* **Determinismo:** la salida depende solo del archivo; no hay hashing ni orden de iteración no determinista que afecte al resultado (los `HashMap` se usan solo para búsquedas puntuales).

## Por qué atender "P1, luego P2, luego P3" equivale a elegir siempre la cola más urgente no vacía

Una pista generada hereda la prioridad de la pista que la creó. Mientras se atiende una pista de prioridad *p*, solo puede entrar trabajo a la cola *p*; nunca aparece trabajo en una prioridad más urgente. Por eso `desencolar()` (primera cola no vacía de 1 a 3) produce exactamente el mismo orden que vaciar P1, luego P2, luego P3.

## Costos (n = fichas, k = pistas)

| Operación | Manual | java.util |
|---|---|---|
| Insertar en lista | O(1) (con referencia a la cola) | O(1) `LinkedList.add` |
| Buscar por id | **O(n)** secuencial | O(1) promedio (`HashMap`) |
| Apilar / retirar / consultar | O(1) | O(1) |
| Encolar / desencolar | O(1) (≤ 3 comparaciones de prioridad) | O(1) |
| Fase 3 completa | O(n) | O(n) |
| Fase 5 completa | **O(k · n)** (cada pista hace 1–2 búsquedas lineales) | O(k) esperado |
| Memoria | O(n) nodos + O(k) pistas | O(n + k) |

La versión manual paga la búsqueda lineal de la lista; la de biblioteca la evita con un índice `HashMap`
(memoria extra O(n)). Las salidas observables son idénticas.

## Archivos de `datos/`

| Archivo | Resultado esperado |
|---|---|
| `ejemplo_valido.txt` | `SOL` (ENCADENAR procesado) |
| `prueba_tres_prioridades.txt` | `SOL` con pistas físicas en orden P3, P2, P1 |
| `prueba_fifo.txt` | `SI` (dos pistas P2: gana el orden de archivo) |
| `prueba_encadenar_cola_vacia.txt` | `AB` (ENCADENAR agrega a una cola que quedó vacía) |
| `prueba_encadenar_orden.txt` | `ACBD` (la generada va al final de P1 y antes que P2) |
| `ejemplo_invalido.txt` | Fase 3, línea 6, F05: se esperaba `]` porque `[` está en el tope |
| `invalido_cierre_sin_apertura.txt` | Fase 3, línea 3, F02 |
| `invalido_apertura_sobrante.txt` | Fase 3, línea 2, F01 |
| `invalido_id_repetido.txt` · `invalido_linea_incompleta.txt` · `invalido_tipo.txt` · `invalido_prioridad.txt` · `invalido_valor.txt` · `invalido_instruccion.txt` · `invalido_encabezado.txt` | Fase 1 |
| `invalido_ref_inexistente.txt` · `invalido_ref_no_letra.txt` · `invalido_letra_repetida.txt` | Fase 5 |
| `invalido_orden_fases.txt` | Error de pila en línea 3 **y** de formato en línea 5: se informa el de formato (fase 1) |

`salidas/` contiene la salida completa de `Main` para cada archivo (útil para las capturas del informe).
