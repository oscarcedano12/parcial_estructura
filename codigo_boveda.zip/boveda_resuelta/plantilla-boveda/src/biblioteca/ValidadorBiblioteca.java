package biblioteca;

import dominio.ErrorBoveda;
import dominio.Eventos;
import dominio.Ficha;
import dominio.Informe;
import dominio.Pista;
import dominio.TipoFicha;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

public final class ValidadorBiblioteca {

    public String ejecutar(List<Ficha> entrada) {
        return resolver(entrada).toString();
    }

    public Informe resolver(List<Ficha> entrada) {
        List<String> traza = new ArrayList<>();
        StringBuilder mensaje = new StringBuilder();
        try {
            traza.add(Eventos.fase(2, "lista enlazada propia"));
            List<Ficha> lista = new LinkedList<>();
            Map<String, Ficha> porId = new HashMap<>();
            for (Ficha f : entrada) {
                lista.add(f);
                porId.put(f.getId(), f);
                traza.add(Eventos.insertar(f, lista.size()));
            }
            StringBuilder ids = new StringBuilder();
            for (Ficha f : lista) {
                if (ids.length() > 0) ids.append(" -> ");
                ids.append(f.getId());
            }
            traza.add(Eventos.recorrido(ids.length() == 0 ? "(vacía)" : ids.toString()));

            traza.add(Eventos.fase(3, "pila de delimitadores"));
            Deque<Ficha> pila = new ArrayDeque<>();  
            for (Ficha f : lista) {
                if (f.getTipo() == TipoFicha.ABRE) {
                    pila.push(f);
                    traza.add(Eventos.apilar(f));
                } else if (f.getTipo() == TipoFicha.CIERRA) {
                    if (pila.isEmpty()) {
                        traza.add(Eventos.consultarVacia(f));
                        throw new ErrorBoveda(ErrorBoveda.PILA, f.getLinea(), f.getPosicion(), f.getId(),
                                "cierre " + f.getValor() + " sin apertura previa (la pila está vacía)");
                    }
                    String tope = pila.peek().getValor();
                    traza.add(Eventos.consultar(tope, f));
                    String esperado = Eventos.cierreDe(tope);
                    if (!esperado.equals(f.getValor())) {
                        throw new ErrorBoveda(ErrorBoveda.PILA, f.getLinea(), f.getPosicion(), f.getId(),
                                "se esperaba " + esperado + " porque " + tope + " está en el tope");
                    }
                    pila.pop();
                    traza.add(Eventos.retirar(tope, f));
                }
            }
            if (!pila.isEmpty()) {
                Ficha apertura = pila.peek();
                traza.add(Eventos.pilaSobrante(apertura.getValor()));
                traza.add(Eventos.buscar(apertura.getId(), porId.get(apertura.getId())));
                throw new ErrorBoveda(ErrorBoveda.PILA, apertura.getLinea(), apertura.getPosicion(),
                        apertura.getId(), "apertura " + apertura.getValor() + " sobrante: nunca se cerró");
            }
            traza.add(Eventos.pilaVaciaAlFinal());

            traza.add(Eventos.fase(4, "colas FIFO por prioridad"));
            List<Queue<Pista>> colas = new ArrayList<>();
            for (int i = 0; i < 3; i++) colas.add(new ArrayDeque<>());   
            for (Ficha f : lista) {
                if (f.getTipo() == TipoFicha.PISTA) {
                    Pista p = Pista.desde(f);
                    colas.get(p.getPrioridad() - 1).offer(p);
                    traza.add(Eventos.encolar(p));
                }
            }

            traza.add(Eventos.fase(5, "resolución de pistas y mensaje"));
            Set<String> reveladas = new HashSet<>();
            Pista p;
            while ((p = siguiente(colas)) != null) {
                traza.add(Eventos.desencolar(p));
                String[] args = p.argumentos();
                Ficha letra = buscarLetra(porId, args[0], p, traza);
                if (!reveladas.add(letra.getId())) {
                    throw errorPista(p, "letra repetida: " + args[0] + " ('" + letra.getValor()
                            + "') ya fue revelada (" + p.contexto() + ")");
                }
                mensaje.append(letra.getValor());
                traza.add(Eventos.mensaje(letra.getValor(), mensaje.toString()));
                if (p.accion().equals("ENCADENAR")) {
                    buscarLetra(porId, args[1], p, traza);
                    Pista generada = p.generarRevelar(args[1]);
                    colas.get(generada.getPrioridad() - 1).offer(generada);
                    traza.add(Eventos.encolar(generada));
                }
            }
        } catch (ErrorBoveda e) {
            traza.add(Eventos.error(e.getMessage()));
            return new Informe(mensaje.toString(), e.getMessage(), traza);
        }
        return new Informe(mensaje.toString(), null, traza);
    }

    private static Pista siguiente(List<Queue<Pista>> colas) {
        for (Queue<Pista> q : colas) {
            if (!q.isEmpty()) return q.poll();
        }
        return null;
    }

    private static Ficha buscarLetra(Map<String, Ficha> porId, String id, Pista p, List<String> traza)
            throws ErrorBoveda {
        Ficha r = porId.get(id);
        traza.add(Eventos.buscar(id, r));
        if (r == null) {
            throw errorPista(p, "referencia inexistente: " + id + " no existe (" + p.contexto() + ")");
        }
        if (r.getTipo() != TipoFicha.LETRA) {
            throw errorPista(p, "referencia inválida: " + id + " es " + r.getTipo()
                    + ", se esperaba LETRA (" + p.contexto() + ")");
        }
        return r;
    }

    private static ErrorBoveda errorPista(Pista p, String detalle) {
        return new ErrorBoveda(ErrorBoveda.RESOLUCION, p.getLinea(), p.getPosicion(), p.getIdOrigen(), detalle);
    }
}
