package dominio;

public final class Eventos {
    private Eventos() {}

    public static String fase(int n, String nombre) { return "== FASE " + n + ": " + nombre + " =="; }

    public static String lecturaEncabezado() { return "LECTURA línea 1: encabezado válido"; }
    public static String lecturaFicha(Ficha f) {
        return "LECTURA línea " + f.getLinea() + ": ficha " + f.getId() + " " + f.getTipo()
                + " valor=" + f.getValor() + " P" + f.getPrioridad() + " instr=" + f.getInstruccion() + " válida";
    }

    public static String insertar(Ficha f, int tamanio) {
        return "LISTA insertar " + f.getId() + " (posición " + f.getPosicion() + ", tamaño " + tamanio + ")";
    }
    public static String recorrido(String ids) { return "LISTA recorrido: " + ids; }
    public static String buscar(String id, Ficha r) {
        if (r == null) return "LISTA buscar " + id + " -> no existe";
        return "LISTA buscar " + id + " -> " + r.getTipo() + (r.getTipo() == TipoFicha.LETRA ? " " + r.getValor() : "");
    }

    public static String apilar(Ficha f) { return "PILA apilar " + f.getValor() + " (por " + f.getId() + ")"; }
    public static String consultarVacia(Ficha f) { return "PILA consultar -> vacía (por " + f.getId() + ")"; }
    public static String consultar(String tope, Ficha f) {
        return "PILA consultar -> tope " + tope + " (por " + f.getId() + ")";
    }
    public static String retirar(String simbolo, Ficha f) {
        return "PILA retirar " + simbolo + " (por " + f.getId() + ")";
    }
    public static String pilaVaciaAlFinal() { return "PILA verificar -> vacía al terminar"; }
    public static String pilaSobrante(String tope) { return "PILA verificar -> quedó " + tope + " sin cerrar"; }
    public static String encolar(Pista p) {
        return "COLA encolar P" + p.getPrioridad() + " " + p.getEtiqueta() + " " + p.getInstruccion();
    }
    public static String desencolar(Pista p) {
        return "COLA desencolar P" + p.getPrioridad() + " " + p.getEtiqueta() + " " + p.getInstruccion();
    }
    public static String mensaje(String letra, String acumulado) {
        return "MENSAJE +" + letra + " -> " + acumulado;
    }

    public static String error(String texto) { return "ERROR " + texto; }

    // Símbolo de cierre que corresponde a una apertura
    public static String cierreDe(String apertura) {
        switch (apertura) {
            case "(": return ")";
            case "[": return "]";
            default:  return "}";
        }
    }
}
