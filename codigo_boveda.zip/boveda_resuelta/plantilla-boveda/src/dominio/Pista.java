package dominio;

public final class Pista {
    private final String etiqueta;
    private final String instruccion;
    private final int prioridad;
    private final String idOrigen;
    private final int linea;
    private final int posicion;
    private final boolean generada;

    private Pista(String etiqueta, String instruccion, int prioridad, String idOrigen,
                  int linea, int posicion, boolean generada) {
        this.etiqueta = etiqueta; this.instruccion = instruccion; this.prioridad = prioridad;
        this.idOrigen = idOrigen; this.linea = linea; this.posicion = posicion; this.generada = generada;
    }

    public static Pista desde(Ficha f) {
        return new Pista(f.getId(), f.getInstruccion(), f.getPrioridad(), f.getId(),
                f.getLinea(), f.getPosicion(), false);
    }

    public Pista generarRevelar(String idDestino) {
        return new Pista("gen(" + idOrigen + ")", "REVELAR:" + idDestino, prioridad,
                idOrigen, linea, posicion, true);
    }

    public String getEtiqueta() { return etiqueta; }
    public String getInstruccion() { return instruccion; }
    public int getPrioridad() { return prioridad; }
    public String getIdOrigen() { return idOrigen; }
    public int getLinea() { return linea; }
    public int getPosicion() { return posicion; }
    public boolean esGenerada() { return generada; }

    public String accion() { return instruccion.split(":")[0]; }
    
    public String[] argumentos() {
        String[] p = instruccion.split(":");
        String[] r = new String[p.length - 1];
        System.arraycopy(p, 1, r, 0, r.length);
        return r;
    }

    public String contexto() {
        return "instrucción " + instruccion + (generada ? " de la pista generada " + etiqueta : "");
    }

    @Override public String toString() { return etiqueta + " " + instruccion; }
}
