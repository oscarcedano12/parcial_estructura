package pruebas;

import app.LectorFichas;
import biblioteca.ValidadorBiblioteca;
import dominio.ErrorBoveda;
import dominio.Ficha;
import dominio.Informe;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import manual.ColaPistas;
import manual.ListaFichas;
import manual.PilaSimbolos;
import manual.ValidadorManual;

public final class CasosPrueba {
    private static int ok = 0, fallos = 0;
    private static Path datos;
    private static Path tmp;

    public static void main(String[] args) throws Exception {
        PrintStream out = new PrintStream(System.out, true, StandardCharsets.UTF_8);
        System.setOut(out);
        datos = Paths.get(args.length > 0 ? args[0] : "datos");
        tmp = Files.createTempDirectory("boveda_pruebas");

        System.out.println("=== A. Estructuras propias, aisladas ===");
        pruebasLista();
        pruebasPila();
        pruebasCola();

        System.out.println("\n=== B. Archivos de datos (manual vs java.util) ===");
       
        valido("ejemplo_valido.txt", "SOL");
        valido("prueba_tres_prioridades.txt", "SOL");   
        valido("prueba_fifo.txt", "SI");                
        valido("prueba_encadenar_cola_vacia.txt", "AB");
        valido("prueba_encadenar_orden.txt", "ACBD");   
        invalido("ejemplo_invalido.txt", 3, "línea física 6, ficha F05 (posición 5): se esperaba ] porque [ está en el tope");
        invalido("invalido_cierre_sin_apertura.txt", 3, "línea física 3, ficha F02 (posición 2): cierre ) sin apertura");
        invalido("invalido_apertura_sobrante.txt", 3, "línea física 2, ficha F01 (posición 1): apertura ( sobrante");
        invalido("invalido_id_repetido.txt", 1, "línea física 4, ficha F02 (posición 3): id repetido 'F02' (ya definido en la línea física 3)");
        invalido("invalido_linea_incompleta.txt", 1, "línea física 3, ficha F02 (posición 2): línea incompleta");
        invalido("invalido_tipo.txt", 1, "línea física 3, ficha F02 (posición 2): tipo inválido 'TEXTO'");
        invalido("invalido_prioridad.txt", 1, "línea física 3, ficha F02 (posición 2): prioridad inválida '4'");
        invalido("invalido_valor.txt", 1, "línea física 2, ficha F01 (posición 1): valor inválido 'x' para ABRE");
        invalido("invalido_instruccion.txt", 1, "línea física 3, ficha F02 (posición 2): instrucción inválida 'REVELAR'");
        invalido("invalido_encabezado.txt", 1, "línea física 1: encabezado inválido");
        invalido("invalido_ref_inexistente.txt", 5, "línea física 5, ficha F04 (posición 4): referencia inexistente: F99");
        invalido("invalido_ref_no_letra.txt", 5, "línea física 5, ficha F04 (posición 4): referencia inválida: F01 es ABRE, se esperaba LETRA");
        invalido("invalido_letra_repetida.txt", 5, "línea física 4, ficha F03 (posición 3): letra repetida: F01 ('S')");
        invalido("invalido_orden_fases.txt", 1, "línea física 5, ficha F04 (posición 4): prioridad inválida '9'");

        System.out.println("\n=== C. Trazas: el error detiene las fases y conserva lo producido ===");
        pruebasTrazas();

        System.out.println("\n=== D. Casos de frontera (contenido generado) ===");
        pruebasFrontera();

        System.out.println("\n=== RESUMEN: " + ok + " correctas, " + fallos + " fallidas ===");
        System.exit(fallos == 0 ? 0 : 1);
    }

    private static void check(String nombre, boolean cond) { check(nombre, cond, ""); }

    private static void check(String nombre, boolean cond, String detalle) {
        if (cond) { ok++; System.out.println("  [OK]    " + nombre); }
        else { fallos++; System.out.println("  [FALLA] " + nombre + (detalle.isEmpty() ? "" : " -> " + detalle)); }
    }

    private static boolean lanza(Class<? extends Throwable> tipo, Runnable r) {
        try { r.run(); return false; } catch (Throwable t) { return tipo.isInstance(t); }
    }

    private static final class Resultado {
        ErrorBoveda errorLectura;   
        Informe manual, biblioteca;
        List<String> trazaLectura = new ArrayList<>();
    }

    private static Resultado procesar(Path ruta) throws IOException {
        Resultado r = new Resultado();
        List<Ficha> fichas;
        try {
            fichas = LectorFichas.leer(ruta, r.trazaLectura);
        } catch (ErrorBoveda e) {
            r.errorLectura = e;
            return r;
        }
        r.manual = new ValidadorManual().resolver(fichas);
        r.biblioteca = new ValidadorBiblioteca().resolver(fichas);
        return r;
    }

    private static Path escribir(String nombre, String contenido) throws IOException {
        Path p = tmp.resolve(nombre);
        Files.write(p, contenido.getBytes(StandardCharsets.UTF_8));
        return p;
    }

    private static final String H = "id|tipo|valor|prioridad|instruccion\n";

    private static void valido(String archivo, String esperado) throws IOException {
        Resultado r = procesar(datos.resolve(archivo));
        if (r.errorLectura != null) { check(archivo, false, "falló la lectura: " + r.errorLectura.getMessage()); return; }
        check(archivo + " -> " + esperado + " (manual)", r.manual.esValido() && r.manual.getMensaje().equals(esperado),
                r.manual.resumen());
        check(archivo + " -> equivalente con java.util", r.manual.equivalente(r.biblioteca));
    }

    private static void invalido(String archivo, int fase, String fragmento) throws IOException {
        Resultado r = procesar(datos.resolve(archivo));
        String error = r.errorLectura != null ? r.errorLectura.getMessage()
                : r.manual.getError() == null ? null : r.manual.getError();
        boolean cumple = error != null && error.startsWith("Fase " + fase) && error.contains(fragmento);
        check(archivo + " -> error en fase " + fase, cumple, String.valueOf(error));
        if (r.errorLectura == null) {
            check(archivo + " -> versiones equivalentes", r.manual.equivalente(r.biblioteca));
        }
    }

    private static Ficha ficha(String id, int pos) {
        return new Ficha(id, dominio.TipoFicha.LETRA, "X", 3, "-", pos, pos + 1);
    }

    private static void pruebasLista() {
        ListaFichas l = new ListaFichas();
        check("Lista: nueva está vacía", l.tamanio() == 0 && l.estaVacia());
        check("Lista: primera() en vacía lanza excepción", lanza(NoSuchElementException.class, l::primera));
        check("Lista: buscar en vacía devuelve null", l.buscar("F01") == null);
        l.agregar(ficha("F01", 1)); l.agregar(ficha("F02", 2)); l.agregar(ficha("F03", 3));
        check("Lista: tamaño 3 tras 3 inserciones", l.tamanio() == 3);
        check("Lista: primera es F01", l.primera().getId().equals("F01"));
        check("Lista: buscar F03 (última) la encuentra", l.buscar("F03") != null && l.buscar("F03").getPosicion() == 3);
        check("Lista: buscar inexistente devuelve null", l.buscar("F99") == null);
        StringBuilder sb = new StringBuilder();
        for (Ficha f : l) sb.append(f.getId());
        check("Lista: recorrido en orden de inserción", sb.toString().equals("F01F02F03"), sb.toString());
        l.agregar(ficha("F04", 4));
        check("Lista: agregar después de buscar mantiene la cola correcta", l.buscar("F04") != null && l.tamanio() == 4);
    }

    private static void pruebasPila() {
        PilaSimbolos p = new PilaSimbolos();
        check("Pila: nueva está vacía", p.estaVacia());
        check("Pila: consultar en vacía lanza excepción", lanza(IllegalStateException.class, p::consultar));
        check("Pila: retirar en vacía lanza excepción", lanza(IllegalStateException.class, p::retirar));
        p.apilar("("); p.apilar("["); p.apilar("{");
        check("Pila: consultar devuelve tope sin retirarlo", p.consultar().equals("{") && p.tamanio() == 3);
        check("Pila: retira en orden LIFO", p.retirar().equals("{") && p.retirar().equals("[") && p.consultar().equals("("));
        p.retirar();
        check("Pila: queda vacía al retirar todo", p.estaVacia() && p.tamanio() == 0);
        p.apilar("[");
        check("Pila: reutilizable tras vaciarse", p.consultar().equals("["));
    }

    private static void pruebasCola() {
        ColaPistas<String> c = new ColaPistas<>();
        check("Cola: nueva está vacía", c.estaVacia());
        check("Cola: desencolar en vacía lanza excepción", lanza(IllegalStateException.class, c::desencolar));
        check("Cola: prioridad 0 rechazada", lanza(IllegalArgumentException.class, () -> c.encolar("x", 0)));
        check("Cola: prioridad 4 rechazada", lanza(IllegalArgumentException.class, () -> c.encolar("x", 4)));

        c.encolar("a3", 3); c.encolar("b2", 2); c.encolar("c1", 1); c.encolar("d2", 2); c.encolar("e1", 1);
        StringBuilder sb = new StringBuilder();
        while (!c.estaVacia()) sb.append(c.desencolar()).append(' ');
        check("Cola: atiende P1, luego P2, luego P3, y FIFO dentro de cada una",
                sb.toString().equals("c1 e1 b2 d2 a3 "), sb.toString());
        c.encolar("p", 2);
        check("Cola: desencolar la única pista de P2", c.desencolar().equals("p") && c.estaVacia());
        c.encolar("q", 2); c.encolar("r", 2);
        check("Cola: reencolar en una cola que quedó vacía conserva FIFO",
                c.desencolar().equals("q") && c.desencolar().equals("r") && c.estaVacia());

        c.encolar("x1", 1); c.encolar("x2", 2);
        check("Cola: tamaño por prioridad", c.tamanio(1) == 1 && c.tamanio(2) == 1 && c.tamanio(3) == 0 && c.tamanio() == 2);
    }

    private static boolean contiene(List<String> traza, String fragmento) {
        for (String e : traza) if (e.contains(fragmento)) return true;
        return false;
    }

    private static void pruebasTrazas() throws IOException {
        Resultado r = procesar(datos.resolve("ejemplo_invalido.txt"));
        check("Error de pila: se conserva la traza de lista y pila",
                contiene(r.manual.getTraza(), "LISTA recorrido: F01 -> F02")
                        && contiene(r.manual.getTraza(), "PILA consultar -> tope ["));
        check("Error de pila: NO se encola ni procesa ninguna pista",
                !contiene(r.manual.getTraza(), "COLA") && !contiene(r.biblioteca.getTraza(), "COLA"));
        check("Error de pila: el mensaje queda vacío", r.manual.getMensaje().isEmpty());

        r = procesar(datos.resolve("invalido_ref_inexistente.txt"));
        check("Error de pista: se conserva la traza de pistas ya atendidas",
                contiene(r.manual.getTraza(), "MENSAJE +S -> S"));
        check("Error de pista: se detiene antes de atender la pista siguiente",
                !contiene(r.manual.getTraza(), "COLA desencolar P3"));
        check("Error de pista: mensaje parcial = S", r.manual.getMensaje().equals("S"));

        r = procesar(datos.resolve("invalido_orden_fases.txt"));
        check("Error de formato (fase 1): no se ejecuta ninguna fase posterior", r.errorLectura != null);

        r = procesar(datos.resolve("ejemplo_valido.txt"));
        List<String> t = r.manual.getTraza();
        check("Traza válida: P1 se atiende antes que P2",
                t.indexOf("COLA desencolar P1 F08 REVELAR:F02") < t.indexOf("COLA desencolar P2 F09 ENCADENAR:F04:F06"));
        check("Traza válida: la pista generada entra al final de P2 y se atiende después",
                contiene(t, "COLA encolar P2 gen(F09) REVELAR:F06")
                        && t.indexOf("COLA encolar P2 gen(F09) REVELAR:F06") < t.indexOf("COLA desencolar P2 gen(F09) REVELAR:F06"));
        check("Traza válida: la pila termina vacía", contiene(t, "PILA verificar -> vacía al terminar"));
        check("Traza válida: mensaje se arma S, SO, SOL",
                contiene(t, "MENSAJE +S -> S") && contiene(t, "MENSAJE +O -> SO") && contiene(t, "MENSAJE +L -> SOL"));
    }

    private static void pruebasFrontera() throws IOException {
        generadoValido("solo encabezado -> mensaje vacío, sin error", H, "");
        generadoValido("sin pistas -> mensaje vacío", H + "F01|LETRA|A|1|-\n", "");
        generadoValido("fin de línea CRLF", H.replace("\n", "\r\n") + "F01|LETRA|A|1|-\r\nF02|PISTA|-|1|REVELAR:F01\r\n", "A");
        generadoValido("BOM UTF-8 al inicio", "﻿" + H + "F01|LETRA|Ñ|1|-\nF02|PISTA|-|1|REVELAR:F01\n", "Ñ");
        generadoValido("líneas vacías finales se ignoran", H + "F01|LETRA|A|1|-\n\n\n", "");
        generadoValido("sin salto de línea final", H + "F01|LETRA|A|1|-\nF02|PISTA|-|1|REVELAR:F01", "A");
        generadoValido("anidamiento profundo y mezclado ({[()]})",
                H + "F01|ABRE|{|3|-\nF02|ABRE|[|3|-\nF03|ABRE|(|3|-\nF04|CIERRA|)|3|-\nF05|CIERRA|]|3|-\nF06|CIERRA|}|3|-\n", "");
        generadoValido("ENCADENAR:F01:F01 no falla al encadenar; falla al atender la generada", H
                + "F01|LETRA|A|1|-\nF02|PISTA|-|1|ENCADENAR:F01:F01\n", null); 
        generadoValido("ENCADENAR en P1 se atiende antes que una REVELAR de P2", H
                + "F01|LETRA|A|1|-\nF02|LETRA|B|1|-\nF03|LETRA|C|2|-\nF04|PISTA|-|2|REVELAR:F03\nF05|PISTA|-|1|ENCADENAR:F01:F02\n", "ABC");

        generadoError("archivo vacío", "", 1, "archivo vacío");
        generadoError("línea en blanco en medio", H + "F01|LETRA|A|1|-\n\nF02|LETRA|B|1|-\n", 1, "línea incompleta");
        generadoError("campos de más", H + "F01|LETRA|A|1|-|extra\n", 1, "línea con campos de más");
        generadoError("prioridad 0", H + "F01|LETRA|A|0|-\n", 1, "prioridad inválida '0'");
        generadoError("prioridad no numérica", H + "F01|LETRA|A|alta|-\n", 1, "prioridad inválida 'alta'");
        generadoError("LETRA con dos caracteres", H + "F01|LETRA|AB|1|-\n", 1, "valor inválido 'AB' para LETRA");
        generadoError("LETRA con dígito", H + "F01|LETRA|7|1|-\n", 1, "valor inválido '7' para LETRA");
        generadoError("ABRE con valor de cierre", H + "F01|ABRE|)|1|-\n", 1, "valor inválido ')' para ABRE");
        generadoError("PISTA con valor distinto de -", H + "F01|PISTA|A|1|REVELAR:F01\n", 1, "valor inválido 'A' para PISTA");
        generadoError("LETRA con instrucción", H + "F01|LETRA|A|1|REVELAR:F01\n", 1, "instrucción inválida 'REVELAR:F01' para LETRA");
        generadoError("ENCADENAR con un solo id", H + "F01|PISTA|-|1|ENCADENAR:F01\n", 1, "instrucción inválida 'ENCADENAR:F01'");
        generadoError("instrucción desconocida", H + "F01|PISTA|-|1|BORRAR:F01\n", 1, "instrucción inválida 'BORRAR:F01'");
        generadoError("tipo en minúsculas", H + "F01|letra|A|1|-\n", 1, "tipo inválido 'letra'");
        generadoError("id vacío", H + "|LETRA|A|1|-\n", 1, "id inválido ''");
        generadoError("ENCADENAR con id2 inexistente (reporta F-origen)",
                H + "F01|LETRA|A|1|-\nF02|PISTA|-|1|ENCADENAR:F01:F77\n", 5, "referencia inexistente: F77");
        generadoError("ENCADENAR con id1 que no es LETRA",
                H + "F01|PISTA|-|1|ENCADENAR:F01:F01\n", 5, "referencia inválida: F01 es PISTA");
        generadoError("ENCADENAR genera REVELAR de letra ya revelada",
                H + "F01|LETRA|A|1|-\nF02|PISTA|-|1|ENCADENAR:F01:F01\n", 5, "letra repetida: F01 ('A')");
        generadoError("letra revelada por REVELAR y luego por ENCADENAR",
                H + "F01|LETRA|A|1|-\nF02|LETRA|B|1|-\nF03|PISTA|-|1|REVELAR:F01\nF04|PISTA|-|1|ENCADENAR:F01:F02\n", 5, "letra repetida: F01");
        generadoError("dos aperturas sin cerrar reporta la más reciente (tope)",
                H + "F01|ABRE|(|1|-\nF02|ABRE|{|1|-\n", 3, "ficha F02 (posición 2): apertura { sobrante");
        generadoError("{ cerrado con )", H + "F01|ABRE|{|1|-\nF02|CIERRA|)|1|-\n", 3, "se esperaba } porque { está en el tope");
    }

    private static void generadoValido(String nombre, String contenido, String esperado) throws IOException {
        Resultado r = procesar(escribir("v" + (ok + fallos) + ".txt", contenido));
        if (r.errorLectura != null) { check(nombre, false, r.errorLectura.getMessage()); return; }
        boolean eq = r.manual.equivalente(r.biblioteca);
        if (esperado == null) {            
            check(nombre + " (error de resolución equivalente)", !r.manual.esValido() && eq, r.manual.resumen());
            return;
        }
        check(nombre, r.manual.esValido() && r.manual.getMensaje().equals(esperado) && eq,
                r.manual.resumen() + (eq ? "" : " [versiones difieren]"));
    }

    private static void generadoError(String nombre, String contenido, int fase, String fragmento) throws IOException {
        Resultado r = procesar(escribir("e" + (ok + fallos) + ".txt", contenido));
        String error = r.errorLectura != null ? r.errorLectura.getMessage() : r.manual.getError();
        boolean eq = r.errorLectura != null || r.manual.equivalente(r.biblioteca);
        check(nombre, error != null && error.startsWith("Fase " + fase) && error.contains(fragmento) && eq,
                String.valueOf(error));
    }
}
