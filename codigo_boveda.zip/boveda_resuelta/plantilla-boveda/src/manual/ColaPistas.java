package manual;

public final class ColaPistas<T> {
    private static final int NIVELES = 3;

    private final Nodo<T>[] frente;
    private final Nodo<T>[] fin;
    private final int[] tamanios;
    private int total;

    @SuppressWarnings({"unchecked", "rawtypes"})
    public ColaPistas() {
        frente = (Nodo<T>[]) new Nodo[NIVELES + 1];
        fin = (Nodo<T>[]) new Nodo[NIVELES + 1];
        tamanios = new int[NIVELES + 1];
    }

    public void encolar(T pista, int prioridad) {
        validarPrioridad(prioridad);
        if (pista == null) throw new IllegalArgumentException("La pista no puede ser null");
        Nodo<T> nuevo = new Nodo<>(pista);
        if (frente[prioridad] == null) {   // cola vacía (incluye una cola que acaba de vaciarse)
            frente[prioridad] = nuevo;
        } else {
            fin[prioridad].siguiente = nuevo;
        }
        fin[prioridad] = nuevo;
        tamanios[prioridad]++;
        total++;
    }

    public T desencolar() {
        for (int p = 1; p <= NIVELES; p++) {
            if (frente[p] != null) {
                T dato = frente[p].dato;
                frente[p] = frente[p].siguiente;
                if (frente[p] == null) fin[p] = null;   
                tamanios[p]--;
                total--;
                return dato;
            }
        }
        throw new IllegalStateException("Las colas están vacías");
    }

    public boolean estaVacia() { return total == 0; }

    public int tamanio() { return total; }

    public int tamanio(int prioridad) {
        validarPrioridad(prioridad);
        return tamanios[prioridad];
    }

    private static void validarPrioridad(int p) {
        if (p < 1 || p > NIVELES) throw new IllegalArgumentException("Prioridad fuera de 1-3: " + p);
    }
}
