package manual;

public final class PilaSimbolos {
    private Nodo<String> tope;
    private int tamanio;

    public void apilar(String simbolo) {
        if (simbolo == null) throw new IllegalArgumentException("El símbolo no puede ser null");
        Nodo<String> nuevo = new Nodo<>(simbolo);
        nuevo.siguiente = tope;
        tope = nuevo;
        tamanio++;
    }

    public String consultar() {
        if (tope == null) throw new IllegalStateException("Pila vacía: no hay tope que consultar");
        return tope.dato;
    }

    public String retirar() {
        if (tope == null) throw new IllegalStateException("Pila vacía: no hay tope que retirar");
        String dato = tope.dato;
        tope = tope.siguiente;
        tamanio--;
        return dato;
    }

    public boolean estaVacia() { return tope == null; }

    public int tamanio() { return tamanio; }
}
