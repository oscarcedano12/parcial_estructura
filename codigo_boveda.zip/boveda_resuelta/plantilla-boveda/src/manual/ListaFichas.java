package manual;

import dominio.Ficha;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class ListaFichas implements Iterable<Ficha> {
    private Nodo<Ficha> cabeza;
    private Nodo<Ficha> cola;
    private int tamanio;

    /** Inserta al final. O(1). */
    public void agregar(Ficha ficha) {
        if (ficha == null) throw new IllegalArgumentException("La ficha no puede ser null");
        Nodo<Ficha> nuevo = new Nodo<>(ficha);
        if (cabeza == null) {          // lista vacía: cabeza y cola son el mismo nodo
            cabeza = nuevo;
            cola = nuevo;
        } else {
            cola.siguiente = nuevo;
            cola = nuevo;
        }
        tamanio++;
    }
    public Ficha buscar(String id) {
        for (Nodo<Ficha> actual = cabeza; actual != null; actual = actual.siguiente) {
            if (actual.dato.getId().equals(id)) return actual.dato;
        }
        return null;
    }

    public int tamanio() { return tamanio; }

    public boolean estaVacia() { return tamanio == 0; }

    public Ficha primera() {
        if (cabeza == null) throw new NoSuchElementException("La lista está vacía");
        return cabeza.dato;
    }

    @Override
    public Iterator<Ficha> iterator() {
        return new Iterator<Ficha>() {
            private Nodo<Ficha> actual = cabeza;
            @Override public boolean hasNext() { return actual != null; }
            @Override public Ficha next() {
                if (actual == null) throw new NoSuchElementException();
                Ficha f = actual.dato;
                actual = actual.siguiente;
                return f;
            }
        };
    }
}
