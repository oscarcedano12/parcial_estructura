package manual;

import dominio.ErrorBoveda;
import dominio.Eventos;
import dominio.Ficha;
import dominio.Informe;
import dominio.Pista;
import dominio.TipoFicha;
import java.util.ArrayList;
import java.util.List;

/**
 * Versión MANUAL: usa ListaFichas, PilaSimbolos y ColaPistas propias.
 * Coordina las fases 2 a 5 (la fase 1, lectura, la hace LectorFichas).
 * Ante el primer error se detienen las fases siguientes y se conserva la traza producida.
 */
public final class ValidadorManual {

    /** Devuelve el informe como texto (mensaje, traza y primer error). */
    public String ejecutar(List<Ficha> entrada) {
        return resolver(entrada).toString();
    }

    /** Devuelve el informe estructurado, útil para comparar con la versión java.util. */
    public Informe resolver(List<Ficha> entrada) {
        List<String> traza = new ArrayList<>();
        StringBuilder mensaje = new StringBuilder();
        try {
            ListaFichas lista = faseLista(entrada, traza);               // Fase 2
            faseDelimitadores(lista, traza);                              // Fase 3
            ColaPistas<Pista> colas = faseEncolar(lista, traza);          // Fase 4
            faseResolver(lista, colas, mensaje, traza, entrada.size());   // Fase 5
        } catch (ErrorBoveda e) {
            traza.add(Eventos.error(e.getMessage()));
            return new Informe(mensaje.toString(), e.getMessage(), traza);
        }
        return new Informe(mensaje.toString(), null, traza);
    }

    // ---------------------------------------------------------------- Fase 2
    private ListaFichas faseLista(List<Ficha> entrada, List<String> traza) {
        traza.add(Eventos.fase(2, "lista enlazada propia"));
        ListaFichas lista = new ListaFichas();
        for (Ficha f : entrada) {
            lista.agregar(f);
            traza.add(Eventos.insertar(f, lista.tamanio()));
        }
        StringBuilder ids = new StringBuilder();
        for (Ficha f : lista) {                       // recorrido en orden de archivo
            if (ids.length() > 0) ids.append(" -> ");
            ids.append(f.getId());
        }
        traza.add(Eventos.recorrido(ids.length() == 0 ? "(vacía)" : ids.toString()));
        return lista;
    }

    // ---------------------------------------------------------------- Fase 3
    private void faseDelimitadores(ListaFichas lista, List<String> traza) throws ErrorBoveda {
        traza.add(Eventos.fase(3, "pila de delimitadores"));
        PilaSimbolos pila = new PilaSimbolos();      // símbolos de apertura
        PilaSimbolos origen = new PilaSimbolos();    // ids de las fichas que abrieron (misma altura)
        for (Ficha f : lista) {
            if (f.getTipo() == TipoFicha.ABRE) {
                pila.apilar(f.getValor());
                origen.apilar(f.getId());
                traza.add(Eventos.apilar(f));
            } else if (f.getTipo() == TipoFicha.CIERRA) {
                if (pila.estaVacia()) {
                    traza.add(Eventos.consultarVacia(f));
                    throw new ErrorBoveda(ErrorBoveda.PILA, f.getLinea(), f.getPosicion(), f.getId(),
                            "cierre " + f.getValor() + " sin apertura previa (la pila está vacía)");
                }
                String tope = pila.consultar();
                traza.add(Eventos.consultar(tope, f));
                String esperado = Eventos.cierreDe(tope);
                if (!esperado.equals(f.getValor())) {
                    throw new ErrorBoveda(ErrorBoveda.PILA, f.getLinea(), f.getPosicion(), f.getId(),
                            "se esperaba " + esperado + " porque " + tope + " está en el tope");
                }
                pila.retirar();
                origen.retirar();
                traza.add(Eventos.retirar(tope, f));
            }
        }
        if (!pila.estaVacia()) {
            String tope = pila.consultar();
            traza.add(Eventos.pilaSobrante(tope));
            Ficha apertura = lista.buscar(origen.consultar());   // ficha que abrió y nunca cerró
            traza.add(Eventos.buscar(apertura.getId(), apertura));
            throw new ErrorBoveda(ErrorBoveda.PILA, apertura.getLinea(), apertura.getPosicion(),
                    apertura.getId(), "apertura " + tope + " sobrante: nunca se cerró");
        }
        traza.add(Eventos.pilaVaciaAlFinal());
    }

    // ---------------------------------------------------------------- Fase 4
    private ColaPistas<Pista> faseEncolar(ListaFichas lista, List<String> traza) {
        traza.add(Eventos.fase(4, "colas FIFO por prioridad"));
        ColaPistas<Pista> colas = new ColaPistas<>();
        for (Ficha f : lista) {
            if (f.getTipo() == TipoFicha.PISTA) {
                Pista p = Pista.desde(f);
                colas.encolar(p, p.getPrioridad());
                traza.add(Eventos.encolar(p));
            }
        }
        return colas;
    }

    // ---------------------------------------------------------------- Fase 5
    private void faseResolver(ListaFichas lista, ColaPistas<Pista> colas, StringBuilder mensaje,
                              List<String> traza, int n) throws ErrorBoveda {
        traza.add(Eventos.fase(5, "resolución de pistas y mensaje"));
        boolean[] reveladas = new boolean[n + 1];     // indexado por Ficha.getPosicion()
        while (!colas.estaVacia()) {
            Pista p = colas.desencolar();             // P1 primero, luego P2, luego P3; FIFO dentro de cada una
            traza.add(Eventos.desencolar(p));
            String[] args = p.argumentos();
            revelar(lista, args[0], p, reveladas, mensaje, traza);
            if (p.accion().equals("ENCADENAR")) {
                buscarLetra(lista, args[1], p, traza);            // valida id2 antes de encadenar
                Pista generada = p.generarRevelar(args[1]);
                colas.encolar(generada, generada.getPrioridad()); // al final de su misma prioridad
                traza.add(Eventos.encolar(generada));
            }
        }
    }

    /** Busca id en la lista y exige que exista y sea LETRA. */
    private Ficha buscarLetra(ListaFichas lista, String id, Pista p, List<String> traza) throws ErrorBoveda {
        Ficha r = lista.buscar(id);
        traza.add(Eventos.buscar(id, r));
        if (r == null) {
            throw errorPista(p, "referencia inexistente: " + id + " no existe (" + p.contexto() + ")");
        }
        if (r.getTipo() != TipoFicha.LETRA) {
            throw errorPista(p, "referencia inválida: " + id + " es " + r.getTipo()
                    + ", se esperaba LETRA (" + p.contexto() + ")");
        }
        return r;
    }

    private void revelar(ListaFichas lista, String id, Pista p, boolean[] reveladas,
                         StringBuilder mensaje, List<String> traza) throws ErrorBoveda {
        Ficha letra = buscarLetra(lista, id, p, traza);
        if (reveladas[letra.getPosicion()]) {
            throw errorPista(p, "letra repetida: " + id + " ('" + letra.getValor()
                    + "') ya fue revelada (" + p.contexto() + ")");
        }
        reveladas[letra.getPosicion()] = true;
        mensaje.append(letra.getValor());
        traza.add(Eventos.mensaje(letra.getValor(), mensaje.toString()));
    }

    private ErrorBoveda errorPista(Pista p, String detalle) {
        return new ErrorBoveda(ErrorBoveda.RESOLUCION, p.getLinea(), p.getPosicion(), p.getIdOrigen(), detalle);
    }
}
