package manual;

import dominio.Ficha;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Lista simplemente enlazada propia con referencia a cabeza y cola.
 *
 * Invariantes:
 *  - tamanio == número de nodos alcanzables desde cabeza.
 *  - cabeza == null  <=>  cola == null  <=>  tamanio == 0.
 *  - cola.siguiente == null y cola es el último nodo alcanzable desde cabeza.
 *  - El orden de los nodos es el orden de inserción (orden del archivo).
 *
 * Costos: agregar O(1) (gracias a la cola), buscar por id O(n), recorrido O(n).
 * El recorrido se expone con Iterable/Iterator: el cliente nunca ve un Nodo.
 */
public final class ListaFichas implements Iterable<Ficha> {
    private Nodo<Ficha> cabeza;
    private Nodo<Ficha> cola;
    private int tamanio;

    /** Inserta al final. O(1). */
    public void agregar(Ficha ficha) {
        if (ficha == null) throw new IllegalArgumentException("La ficha no puede ser null");
        Nodo<Ficha> nuevo = new Nodo<>(ficha);
        if (cabeza == null) {          // lista vacía: cabeza y cola son el mismo nodo
            cabeza = nuevo;
            cola = nuevo;
        } else {
            cola.siguiente = nuevo;
            cola = nuevo;
        }
        tamanio++;
    }

    /** Búsqueda secuencial por id. Devuelve null si no existe. O(n). */
    public Ficha buscar(String id) {
        for (Nodo<Ficha> actual = cabeza; actual != null; actual = actual.siguiente) {
            if (actual.dato.getId().equals(id)) return actual.dato;
        }
        return null;
    }

    public int tamanio() { return tamanio; }

    public boolean estaVacia() { return tamanio == 0; }

    /** Primera ficha (la de menor posición). Lanza excepción si la lista está vacía. */
    public Ficha primera() {
        if (cabeza == null) throw new NoSuchElementException("La lista está vacía");
        return cabeza.dato;
    }

    /** Recorrido en orden de archivo sin exponer Nodo. */
    @Override
    public Iterator<Ficha> iterator() {
        return new Iterator<Ficha>() {
            private Nodo<Ficha> actual = cabeza;
            @Override public boolean hasNext() { return actual != null; }
            @Override public Ficha next() {
                if (actual == null) throw new NoSuchElementException();
                Ficha f = actual.dato;
                actual = actual.siguiente;
                return f;
            }
        };
    }
}
