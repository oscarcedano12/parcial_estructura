package manual;

/**
 * Pila propia (LIFO) con lista enlazada: el tope es la cabeza de la cadena.
 *
 * Invariantes:
 *  - tamanio == nodos alcanzables desde tope; tope == null <=> tamanio == 0.
 *  - Solo apilar y retirar modifican la pila; consultar NUNCA la modifica.
 *
 * Costos: apilar, consultar, retirar y estaVacia son O(1).
 */
public final class PilaSimbolos {
    private Nodo<String> tope;
    private int tamanio;

    public void apilar(String simbolo) {
        if (simbolo == null) throw new IllegalArgumentException("El símbolo no puede ser null");
        Nodo<String> nuevo = new Nodo<>(simbolo);
        nuevo.siguiente = tope;
        tope = nuevo;
        tamanio++;
    }

    /** Devuelve el tope sin retirarlo. */
    public String consultar() {
        if (tope == null) throw new IllegalStateException("Pila vacía: no hay tope que consultar");
        return tope.dato;
    }

    /** Retira y devuelve el tope. */
    public String retirar() {
        if (tope == null) throw new IllegalStateException("Pila vacía: no hay tope que retirar");
        String dato = tope.dato;
        tope = tope.siguiente;
        tamanio--;
        return dato;
    }

    public boolean estaVacia() { return tope == null; }

    public int tamanio() { return tamanio; }
}
