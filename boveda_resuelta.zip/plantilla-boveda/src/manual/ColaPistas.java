package manual;

/**
 * Tres colas FIFO propias (una por prioridad 1, 2 y 3), cada una con su propio frente y fin.
 *
 * Decisión de representación: arreglos de tamaño 4 indexados DIRECTAMENTE por la prioridad
 * (la posición 0 no se usa). Así encolar en la prioridad p es O(1) y no hay búsqueda.
 *
 * Invariantes (para cada p en 1..3):
 *  - frente[p] == null <=> fin[p] == null <=> tamanios[p] == 0.
 *  - fin[p] es el último nodo alcanzable desde frente[p] y fin[p].siguiente == null.
 *  - Dentro de una prioridad se atiende en orden de llegada (FIFO).
 *
 * desencolar() atiende primero la cola 1, luego la 2 y luego la 3. Esto es equivalente a
 * "vaciar P1, luego P2, luego P3" porque una pista generada siempre hereda la prioridad
 * de la pista que la creó, así que ninguna atención puede agregar trabajo a una cola de
 * prioridad más urgente que la que se está atendiendo.
 *
 * Costos: encolar O(1), desencolar O(1) (a lo sumo 3 comparaciones), estaVacia O(1).
 */
public final class ColaPistas<T> {
    private static final int NIVELES = 3;

    private final Nodo<T>[] frente;
    private final Nodo<T>[] fin;
    private final int[] tamanios;
    private int total;

    @SuppressWarnings({"unchecked", "rawtypes"})
    public ColaPistas() {
        frente = (Nodo<T>[]) new Nodo[NIVELES + 1];
        fin = (Nodo<T>[]) new Nodo[NIVELES + 1];
        tamanios = new int[NIVELES + 1];
    }

    public void encolar(T pista, int prioridad) {
        validarPrioridad(prioridad);
        if (pista == null) throw new IllegalArgumentException("La pista no puede ser null");
        Nodo<T> nuevo = new Nodo<>(pista);
        if (frente[prioridad] == null) {   // cola vacía (incluye una cola que acaba de vaciarse)
            frente[prioridad] = nuevo;
        } else {
            fin[prioridad].siguiente = nuevo;
        }
        fin[prioridad] = nuevo;
        tamanios[prioridad]++;
        total++;
    }

    /** Retira la pista más antigua de la prioridad más urgente que tenga trabajo. */
    public T desencolar() {
        for (int p = 1; p <= NIVELES; p++) {
            if (frente[p] != null) {
                T dato = frente[p].dato;
                frente[p] = frente[p].siguiente;
                if (frente[p] == null) fin[p] = null;   // al vaciarse, el fin también se reinicia
                tamanios[p]--;
                total--;
                return dato;
            }
        }
        throw new IllegalStateException("Las colas están vacías");
    }

    public boolean estaVacia() { return total == 0; }

    public int tamanio() { return total; }

    public int tamanio(int prioridad) {
        validarPrioridad(prioridad);
        return tamanios[prioridad];
    }

    private static void validarPrioridad(int p) {
        if (p < 1 || p > NIVELES) throw new IllegalArgumentException("Prioridad fuera de 1-3: " + p);
    }
}
