package dominio;

/**
 * Error de formato, anidamiento o referencia detectado al procesar la bóveda.
 * El mensaje ya viene formateado: fase, línea física, ficha y posición.
 */
public final class ErrorBoveda extends Exception {
    public static final int LECTURA = 1;
    public static final int LISTA = 2;
    public static final int PILA = 3;
    public static final int COLAS = 4;
    public static final int RESOLUCION = 5;

    private static final long serialVersionUID = 1L;
    private static final String[] NOMBRES_FASE = {"", "lectura", "lista", "pila", "colas", "resolución"};

    private final int fase;

    /**
     * @param fase     número de fase (1..5)
     * @param linea    línea física del archivo (&lt;= 0 si no aplica)
     * @param posicion número de ficha leído (&lt;= 0 si no aplica)
     * @param id       id de la ficha (null o vacío si no se conoce)
     * @param detalle  descripción del problema
     */
    public ErrorBoveda(int fase, int linea, int posicion, String id, String detalle) {
        super(formatear(fase, linea, posicion, id, detalle));
        this.fase = fase;
    }

    public int getFase() { return fase; }

    private static String formatear(int fase, int linea, int posicion, String id, String detalle) {
        StringBuilder sb = new StringBuilder("Fase ").append(fase)
                .append(" (").append(NOMBRES_FASE[fase]).append(")");
        if (linea > 0) {
            sb.append(" | línea física ").append(linea);
            if (posicion > 0) {
                sb.append(", ficha ").append(id == null || id.isEmpty() ? "(sin id)" : id)
                  .append(" (posición ").append(posicion).append(")");
            }
        }
        return sb.append(": ").append(detalle).toString();
    }
}
