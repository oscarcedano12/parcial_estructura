package dominio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/** Resultado de ejecutar una versión del validador: mensaje, primer error y traza. */
public final class Informe {
    private final String mensaje;
    private final String error; // null si todo fue válido
    private final List<String> traza;

    public Informe(String mensaje, String error, List<String> traza) {
        this.mensaje = mensaje;
        this.error = error;
        this.traza = Collections.unmodifiableList(new ArrayList<>(traza));
    }

    public String getMensaje() { return mensaje; }
    public String getError() { return error; }
    public List<String> getTraza() { return traza; }
    public boolean esValido() { return error == null; }

    /** Equivalencia observable: mismo mensaje, mismo primer error y mismos eventos en el mismo orden. */
    public boolean equivalente(Informe otro) {
        return mensaje.equals(otro.mensaje)
                && Objects.equals(error, otro.error)
                && traza.equals(otro.traza);
    }

    /** Línea de resumen: mensaje final o error. */
    public String resumen() {
        if (esValido()) return "Mensaje: " + (mensaje.isEmpty() ? "(vacío)" : mensaje) + " | Primer error: ninguno";
        return "Mensaje: " + (mensaje.isEmpty() ? "(ninguno)" : "(incompleto, parcial = " + mensaje + ")")
                + " | Primer error: " + error;
    }

    @Override public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String e : traza) sb.append("  ").append(e).append('\n');
        return sb.append(resumen()).toString();
    }
}
