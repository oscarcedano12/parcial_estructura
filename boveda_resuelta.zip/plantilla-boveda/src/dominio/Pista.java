package dominio;

/**
 * Tarea que viaja por las colas de prioridad. Puede venir de una ficha PISTA del
 * archivo o ser generada por un ENCADENAR (siempre un REVELAR en la misma prioridad).
 * Conserva línea y posición de la ficha de origen para reportar errores.
 */
public final class Pista {
    private final String etiqueta;
    private final String instruccion;
    private final int prioridad;
    private final String idOrigen;
    private final int linea;
    private final int posicion;
    private final boolean generada;

    private Pista(String etiqueta, String instruccion, int prioridad, String idOrigen,
                  int linea, int posicion, boolean generada) {
        this.etiqueta = etiqueta; this.instruccion = instruccion; this.prioridad = prioridad;
        this.idOrigen = idOrigen; this.linea = linea; this.posicion = posicion; this.generada = generada;
    }

    public static Pista desde(Ficha f) {
        return new Pista(f.getId(), f.getInstruccion(), f.getPrioridad(), f.getId(),
                f.getLinea(), f.getPosicion(), false);
    }

    /** Pista REVELAR:idDestino que hereda prioridad y origen de esta pista. */
    public Pista generarRevelar(String idDestino) {
        return new Pista("gen(" + idOrigen + ")", "REVELAR:" + idDestino, prioridad,
                idOrigen, linea, posicion, true);
    }

    public String getEtiqueta() { return etiqueta; }
    public String getInstruccion() { return instruccion; }
    public int getPrioridad() { return prioridad; }
    public String getIdOrigen() { return idOrigen; }
    public int getLinea() { return linea; }
    public int getPosicion() { return posicion; }
    public boolean esGenerada() { return generada; }

    /** Tipo de acción: REVELAR o ENCADENAR. */
    public String accion() { return instruccion.split(":")[0]; }
    /** Argumentos de la instrucción (ids referenciados). */
    public String[] argumentos() {
        String[] p = instruccion.split(":");
        String[] r = new String[p.length - 1];
        System.arraycopy(p, 1, r, 0, r.length);
        return r;
    }

    /** Texto de contexto para los errores de resolución. */
    public String contexto() {
        return "instrucción " + instruccion + (generada ? " de la pista generada " + etiqueta : "");
    }

    @Override public String toString() { return etiqueta + " " + instruccion; }
}
