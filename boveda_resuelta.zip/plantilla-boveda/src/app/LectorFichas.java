package app;

import dominio.ErrorBoveda;
import dominio.Eventos;
import dominio.Ficha;
import dominio.TipoFicha;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Fase 1: lee el archivo UTF-8 y valida encabezado, cinco campos por fila, tipo, valor,
 * prioridad, instrucción (solo sintaxis) e identificadores únicos. Registra línea física
 * y posición de cada ficha. Se detiene en el PRIMER error en orden de lectura.
 *
 * Aquí se permiten utilidades de Java (Files, split, HashMap para detectar ids repetidos);
 * la lista, la pila y las colas del algoritmo sí son propias.
 */
public final class LectorFichas {
    public static final String ENCABEZADO = "id|tipo|valor|prioridad|instruccion";

    private static final Pattern ID = Pattern.compile("[A-Za-z0-9_]+");
    private static final Pattern INSTR_PISTA =
            Pattern.compile("REVELAR:[A-Za-z0-9_]+|ENCADENAR:[A-Za-z0-9_]+:[A-Za-z0-9_]+");

    private LectorFichas() {}

    public static List<Ficha> leer(Path ruta) throws IOException, ErrorBoveda {
        return leer(ruta, new ArrayList<>());
    }

    /** Igual que {@link #leer(Path)} pero agrega los eventos de lectura a la traza dada. */
    public static List<Ficha> leer(Path ruta, List<String> traza) throws IOException, ErrorBoveda {
        List<String> lineas = Files.readAllLines(ruta, StandardCharsets.UTF_8);
        traza.add(Eventos.fase(1, "lectura y validación del archivo"));

        if (lineas.isEmpty()) {
            throw new ErrorBoveda(ErrorBoveda.LECTURA, 1, 0, null,
                    "archivo vacío: falta el encabezado '" + ENCABEZADO + "'");
        }
        // Un BOM UTF-8 al inicio no forma parte del encabezado
        String primera = lineas.get(0);
        if (primera.startsWith("﻿")) primera = primera.substring(1);
        if (!primera.equals(ENCABEZADO)) {
            throw new ErrorBoveda(ErrorBoveda.LECTURA, 1, 0, null,
                    "encabezado inválido '" + primera + "'; se esperaba '" + ENCABEZADO + "'");
        }
        traza.add(Eventos.lecturaEncabezado());

        // Líneas vacías al final del archivo no son fichas
        int ultima = lineas.size();
        while (ultima > 1 && lineas.get(ultima - 1).isEmpty()) ultima--;

        List<Ficha> fichas = new ArrayList<>();
        Map<String, Integer> lineaDeId = new HashMap<>();

        for (int i = 1; i < ultima; i++) {
            int linea = i + 1;                       // línea física (el encabezado es la 1)
            int posicion = fichas.size() + 1;        // número de ficha leído
            Ficha f = interpretar(lineas.get(i), linea, posicion, lineaDeId);
            lineaDeId.put(f.getId(), linea);
            fichas.add(f);
            traza.add(Eventos.lecturaFicha(f));
        }
        return fichas;
    }

    private static Ficha interpretar(String texto, int linea, int posicion, Map<String, Integer> lineaDeId)
            throws ErrorBoveda {
        String[] c = texto.split("\\|", -1);          // -1 conserva campos vacíos al final
        String idTentativo = c.length > 0 ? c[0] : null;
        if (c.length != 5) {
            throw error(linea, posicion, idTentativo,
                    "línea " + (c.length < 5 ? "incompleta" : "con campos de más")
                            + ": se esperaban 5 campos separados por | y hay " + c.length);
        }
        String id = c[0], tipoTxt = c[1], valor = c[2], prioTxt = c[3], instr = c[4];

        // id
        if (!ID.matcher(id).matches()) {
            throw error(linea, posicion, id, "id inválido '" + id + "' (solo letras, dígitos y _)");
        }
        Integer previa = lineaDeId.get(id);
        if (previa != null) {
            throw error(linea, posicion, id,
                    "id repetido '" + id + "' (ya definido en la línea física " + previa + ")");
        }
        // tipo
        TipoFicha tipo;
        try {
            tipo = TipoFicha.valueOf(tipoTxt);
        } catch (IllegalArgumentException e) {
            throw error(linea, posicion, id,
                    "tipo inválido '" + tipoTxt + "' (use ABRE, CIERRA, LETRA o PISTA)");
        }
        // valor según tipo
        switch (tipo) {
            case ABRE:
                if (!(valor.equals("(") || valor.equals("[") || valor.equals("{")))
                    throw error(linea, posicion, id, "valor inválido '" + valor + "' para ABRE (use ( [ o {)");
                break;
            case CIERRA:
                if (!(valor.equals(")") || valor.equals("]") || valor.equals("}")))
                    throw error(linea, posicion, id, "valor inválido '" + valor + "' para CIERRA (use ) ] o })");
                break;
            case LETRA:
                if (!(valor.length() == 1 && Character.isLetter(valor.charAt(0))))
                    throw error(linea, posicion, id, "valor inválido '" + valor + "' para LETRA (una sola letra)");
                break;
            default: // PISTA
                if (!valor.equals("-"))
                    throw error(linea, posicion, id, "valor inválido '" + valor + "' para PISTA (use -)");
        }
        // prioridad
        if (!(prioTxt.equals("1") || prioTxt.equals("2") || prioTxt.equals("3"))) {
            throw error(linea, posicion, id, "prioridad inválida '" + prioTxt + "' (debe ser 1, 2 o 3)");
        }
        int prioridad = Integer.parseInt(prioTxt);
        // instrucción (solo sintaxis; la existencia de los ids se verifica al resolver)
        if (tipo == TipoFicha.PISTA) {
            if (!INSTR_PISTA.matcher(instr).matches())
                throw error(linea, posicion, id,
                        "instrucción inválida '" + instr + "' (use REVELAR:id o ENCADENAR:id1:id2)");
        } else if (!instr.equals("-")) {
            throw error(linea, posicion, id,
                    "instrucción inválida '" + instr + "' para " + tipo + " (use -)");
        }
        return new Ficha(id, tipo, valor, prioridad, instr, posicion, linea);
    }

    private static ErrorBoveda error(int linea, int posicion, String id, String detalle) {
        return new ErrorBoveda(ErrorBoveda.LECTURA, linea, posicion, id, detalle);
    }
}
