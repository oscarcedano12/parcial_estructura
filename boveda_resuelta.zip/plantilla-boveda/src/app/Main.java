package app;

import biblioteca.ValidadorBiblioteca;
import dominio.ErrorBoveda;
import dominio.Ficha;
import dominio.Informe;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import manual.ValidadorManual;

/**
 * Punto de entrada. Uso: java -cp out app.Main &lt;archivo.txt&gt;
 *
 * Códigos de salida: 0 = bóveda válida y versiones equivalentes; 1 = error en el archivo
 * (formato, anidamiento o referencia); 2 = uso incorrecto o archivo ilegible;
 * 3 = las dos versiones NO coinciden (defecto del programa).
 */
public final class Main {
    private Main() {}

    public static void main(String[] args) {
        PrintStream out = new PrintStream(System.out, true, StandardCharsets.UTF_8);
        if (args.length != 1) {
            out.println("Uso: java -cp out app.Main <archivo.txt>");
            System.exit(2);
        }
        System.exit(ejecutar(Paths.get(args[0]), out));
    }

    /** Ejecuta todo el flujo y devuelve el código de salida. Separado de main para poder probarlo. */
    public static int ejecutar(Path ruta, PrintStream out) {
        out.println("Archivo: " + ruta);
        List<String> trazaLectura = new ArrayList<>();
        List<Ficha> fichas;
        try {
            fichas = LectorFichas.leer(ruta, trazaLectura);
        } catch (ErrorBoveda e) {
            // Fase 1 falló: no se ejecutan las fases posteriores (ni la lista, ni la pila, ni las colas)
            imprimir(out, trazaLectura);
            out.println("  ERROR " + e.getMessage());
            out.println();
            out.println("RESULTADO: error -> " + e.getMessage());
            return 1;
        } catch (IOException e) {
            out.println("No se pudo leer el archivo: " + e.getMessage());
            return 2;
        }
        imprimir(out, trazaLectura);

        Informe manual = new ValidadorManual().resolver(fichas);
        Informe biblioteca = new ValidadorBiblioteca().resolver(fichas);

        out.println();
        out.println("##### VERSIÓN MANUAL (lista, pila y colas propias) #####");
        imprimir(out, manual.getTraza());
        out.println("  " + manual.resumen());

        out.println();
        out.println("##### VERSIÓN java.util #####");
        out.println("  " + biblioteca.resumen());
        out.println("  Eventos en la traza: " + biblioteca.getTraza().size());

        out.println();
        out.println("##### COMPARACIÓN #####");
        boolean igualMensaje = manual.getMensaje().equals(biblioteca.getMensaje());
        boolean igualError = java.util.Objects.equals(manual.getError(), biblioteca.getError());
        boolean igualTraza = manual.getTraza().equals(biblioteca.getTraza());
        out.println("  Mensaje:      " + (igualMensaje ? "IGUAL" : "DIFERENTE"));
        out.println("  Primer error: " + (igualError ? "IGUAL" : "DIFERENTE"));
        out.println("  Traza:        " + (igualTraza ? "IGUAL" : "DIFERENTE")
                + " (" + manual.getTraza().size() + " eventos vs " + biblioteca.getTraza().size() + ")");
        if (!igualTraza) {
            out.println("  --- traza java.util ---");
            imprimir(out, biblioteca.getTraza());
        }
        out.println();
        if (!(igualMensaje && igualError && igualTraza)) {
            out.println("RESULTADO: las versiones NO son equivalentes");
            return 3;
        }
        if (manual.esValido()) {
            out.println("RESULTADO: " + manual.getMensaje());
            return 0;
        }
        out.println("RESULTADO: error -> " + manual.getError());
        return 1;
    }

    private static void imprimir(PrintStream out, List<String> eventos) {
        for (String e : eventos) out.println("  " + e);
    }
}
